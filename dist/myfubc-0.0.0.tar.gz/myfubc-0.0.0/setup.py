import setuptools


setuptools.setup (name='myfubc',py_modules=['sole_decorators']
    
)